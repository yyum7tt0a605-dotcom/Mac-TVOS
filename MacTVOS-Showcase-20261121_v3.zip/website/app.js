'use strict';
const $ = (q) => document.querySelector(q);
$('#compare-range').addEventListener('input',event=>$('.comparison').style.setProperty('--pos',`${event.target.value}%`));
document.querySelectorAll('[data-material]').forEach(button=>button.addEventListener('click',()=>{
 document.querySelectorAll('[data-material]').forEach(b=>{b.classList.toggle('active',b===button);b.setAttribute('aria-pressed',String(b===button));});
 const matte=button.dataset.material==='matte';$('#material-image').src=matte?'img/clock-matte.jpg':'img/clock-glass.jpg';$('#material-image').alt=matte?'白色霧面漸層時鐘的實機效果':'透明磨砂玻璃時鐘的實機效果';$('#material-image').parentElement.setAttribute('aria-label','放大圖片：'+$('#material-image').alt);
}));
let lastImageTrigger;
const dialog=$('#image-dialog');
document.querySelectorAll('.zoomable').forEach(figure=>{
 figure.tabIndex=0;figure.setAttribute('role','button');figure.setAttribute('aria-label','放大圖片：'+figure.querySelector('img').alt);
 function show(){lastImageTrigger=figure;dialog.querySelector('img').src=figure.querySelector('img').src;dialog.querySelector('img').alt=figure.querySelector('img').alt;dialog.querySelector('p').textContent=figure.querySelector('img').alt;dialog.showModal();}
 figure.addEventListener('click',show);figure.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();show();}});
});
$('.dialog-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});dialog.addEventListener('close',()=>lastImageTrigger?.focus());
function renderTests(filter='all'){
 const body=$('#test-body');body.replaceChildren();const rows=window.MACTVOS_TESTS?.tests||[];
 rows.filter(row=>filter==='all'||row.status===filter).forEach(row=>{
  const tr=document.createElement('tr');const title=document.createElement('td');title.textContent=row.name;
  const status=document.createElement('td');const label=document.createElement('span');label.className='result '+row.status;label.textContent=row.status==='pass'?'已確認':'範圍限制';status.append(label);
  const description=document.createElement('td');description.textContent=row.note;tr.append(title,status,description);body.append(tr);
 });
}
document.querySelectorAll('[data-filter]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-filter]').forEach(b=>{b.classList.toggle('active',b===button);b.setAttribute('aria-pressed',String(b===button));});renderTests(button.dataset.filter);}));renderTests();
$('#copy-command').addEventListener('click',async()=>{const b=$('#copy-command');try{await navigator.clipboard.writeText($('#install-command').textContent);b.textContent='已複製';}catch{b.textContent='請選取左側指令複製';}setTimeout(()=>b.textContent='複製指令',3000);});
if(window.MACTVOS_HAS_DEMO)$('#demo').hidden=false;
let release,controller;
function hex(bytes){return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join('');}
const button=$('#download-button'),status=$('#download-status'),cancel=$('#cancel-download'),progress=$('#download-progress');
async function loadRelease(){
 if(location.protocol==='file:'||window.MACTVOS_OFFLINE){button.disabled=true;button.textContent='已在安裝包內';status.textContent='這是離線成果頁。回到上一層資料夾，依 README 執行安裝即可。';$('#zip-hash').textContent='見安裝包旁的 SHA256 校驗檔';return;}
 try{const response=await fetch('download/release-download.json',{cache:'no-cache'});if(!response.ok)throw Error('下載資訊暫時無法取得');release=await response.json();status.textContent=`完整 ZIP · ${(release.bytes/1024/1024).toFixed(1)} MiB · 建議使用電腦下載；下載後自動校驗。`;$('#zip-hash').textContent=release.sha256;}
 catch(error){button.disabled=true;status.textContent='下載資訊暫時無法取得，請稍後重新整理頁面。';}
}
loadRelease();cancel.addEventListener('click',()=>controller?.abort());
button.addEventListener('click',async()=>{
 if(!release||controller)return;
 if(!crypto.subtle){status.textContent='此瀏覽器無法進行 SHA-256 校驗，請改用新版 Chrome、Edge 或 Safari 的安全連線。';return;}
 controller=new AbortController();button.disabled=true;cancel.hidden=false;progress.hidden=false;progress.value=0;
 try{
  const parts=new Array(release.parts.length);let completed=0,next=0;
  async function worker(){while(next<release.parts.length){const index=next++,part=release.parts[index];let bytes;
   if(part.remote){
    if(!window.MacTVOSRemoteParts?.fetch)throw Error('遠端下載通道未載入，請重新整理頁面');
    bytes=await window.MacTVOSRemoteParts.fetch(release.remote_base,part.file,controller.signal);
   }else{
    const response=await fetch('download/'+part.file,{signal:controller.signal});
    if(!response.ok)throw Error(`分段 ${index+1} 下載失敗`);
    bytes=await response.arrayBuffer();
   }
   if(bytes.byteLength!==part.bytes||hex(await crypto.subtle.digest('SHA-256',bytes))!==part.sha256)throw Error(`分段 ${index+1} 校驗失敗，請重試`);parts[index]=bytes;completed+=bytes.byteLength;progress.value=completed/release.bytes*100;status.textContent=`下載與校驗中：${(completed/1024/1024).toFixed(1)} / ${(release.bytes/1024/1024).toFixed(1)} MiB`;}}
  await Promise.all([worker(),worker(),worker()]);status.textContent='所有分段已完成，正在核對整包 SHA-256…';
  const blob=new Blob(parts,{type:'application/zip'});if(blob.size!==release.bytes||hex(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer()))!==release.sha256)throw Error('完整 ZIP 校驗不符，未儲存檔案。');
  const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=release.filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  status.textContent='完整 ZIP 校驗通過，已交給瀏覽器儲存。解壓縮後先閱讀 README。';
 }catch(error){controller.abort();status.textContent=error.name==='AbortError'?'下載已取消，可重新開始。':'下載未完成：'+error.message+'。請重新下載。';}
 finally{controller=null;button.disabled=false;cancel.hidden=true;}
});

// Showcase filters and actual desktop photo rotation.
const galleryCards=[...document.querySelectorAll('[data-gallery-kind]')];
document.querySelectorAll('[data-gallery-filter]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-gallery-filter]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));let count=0;galleryCards.forEach(c=>{c.hidden=b.dataset.galleryFilter!=='all'&&c.dataset.galleryKind!==b.dataset.galleryFilter;if(!c.hidden)count++;});$('#gallery-count').textContent=count+' 張實機照片';}));
const heroVideo=$('#hero-video');
if(heroVideo){
 heroVideo.muted=true;
 const attempt=heroVideo.play();
 if(attempt)attempt.catch(()=>{$('.hero-video-fallback').hidden=false;});
 heroVideo.addEventListener('playing',()=>{$('.hero-video-fallback').hidden=true;});
}

// Display supplied captures only after the real image loads successfully.
document.querySelectorAll('[data-pending-src]').forEach(img=>{
 const capture=new Image();
 capture.onload=()=>{img.src=img.dataset.pendingSrc;img.hidden=false;const figure=img.closest('figure');figure.querySelector('figcaption').textContent=img.alt+' · 實機截圖';figure.classList.add('capture-ready');figure.tabIndex=0;figure.setAttribute('role','button');figure.setAttribute('aria-label','放大圖片：'+img.alt);
 const show=()=>{lastImageTrigger=figure;dialog.querySelector('img').src=img.src;dialog.querySelector('img').alt=img.alt;dialog.querySelector('p').textContent=img.alt;dialog.showModal();};
 figure.addEventListener('click',show);figure.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();show();}});};
 capture.src=img.dataset.pendingSrc;
});
