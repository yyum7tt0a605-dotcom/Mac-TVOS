/* Binary transport only. Caller must verify each returned part with SHA-256. */
(() => {
 'use strict';
 const ASSET_ORIGIN = 'https://mac-tvos-install-assets.yyum7tt03.chatgpt.site';
 const MAX_BYTES = 8 * 1024 * 1024;
 const validFile = file => typeof file === 'string' && /^[A-Za-z0-9][A-Za-z0-9._-]{0,180}$/.test(file) && !file.includes('..');
 const abortError = () => new DOMException('分段下載已取消', 'AbortError');
 function fetchPart(baseUrl, file, signal) {
  return new Promise((resolve, reject) => {
   let base;
   try { base = new URL(baseUrl); } catch { reject(new Error('資源站網址無效')); return; }
   if (base.origin !== ASSET_ORIGIN || base.pathname !== '/' || base.search || base.hash || base.username || base.password) { reject(new Error('不允許的分段資源站')); return; }
   if (!validFile(file)) { reject(new Error('分段檔名無效')); return; }
   if (signal?.aborted) { reject(abortError()); return; }
   const requestId = crypto.randomUUID();
   const frame = document.createElement('iframe');
   frame.hidden = true;
   frame.title = '安裝包分段下載通道';
   frame.referrerPolicy = 'no-referrer';
   frame.setAttribute('sandbox', 'allow-scripts allow-same-origin');
   let settled = false, timer;
   function finish(error, bytes) {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    window.removeEventListener('message', onMessage);
    signal?.removeEventListener('abort', onAbort);
    frame.remove();
    if (error) reject(error); else resolve(bytes);
   }
   function cancelRemote() {
    frame.contentWindow?.postMessage({ protocol: 'mactvos-parts-v1', type: 'abort', requestId }, ASSET_ORIGIN);
   }
   function onAbort() { cancelRemote(); finish(abortError()); }
   function onMessage(event) {
    if (event.source !== frame.contentWindow || event.origin !== ASSET_ORIGIN) return;
    const data = event.data;
    if (!data || data.protocol !== 'mactvos-parts-v1' || data.requestId !== requestId) return;
    if (data.type === 'error') { finish(new Error(typeof data.error === 'string' ? data.error.slice(0, 300) : '資源站下載失敗')); return; }
    if (data.type !== 'result') return;
    if (!(data.bytes instanceof ArrayBuffer) || data.bytes.byteLength === 0 || data.bytes.byteLength > MAX_BYTES) { finish(new Error('資源站回傳分段大小或格式無效')); return; }
    finish(null, data.bytes);
   }
   frame.onload = () => {
    if (settled) return;
    clearTimeout(timer);
    timer = setTimeout(() => { cancelRemote(); finish(new Error('分段下載逾時（90 秒）')); }, 90000);
    frame.contentWindow.postMessage({ protocol: 'mactvos-parts-v1', type: 'fetch', requestId, file }, ASSET_ORIGIN);
   };
   frame.onerror = () => finish(new Error('無法載入資源站下載通道'));
   window.addEventListener('message', onMessage);
   signal?.addEventListener('abort', onAbort, { once: true });
   timer = setTimeout(() => finish(new Error('下載通道載入逾時（15 秒）')), 15000);
   frame.src = ASSET_ORIGIN + '/loader.html';
   document.body.append(frame);
  });
 }
 window.MacTVOSRemoteParts = Object.freeze({ fetch: fetchPart });
})();
