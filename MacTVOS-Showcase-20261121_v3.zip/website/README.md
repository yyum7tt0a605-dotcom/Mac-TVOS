# Mac TVOS 成果網站

2026-11-21。保留首頁主影片，下方另外展示 Dock、應用程式庫滑動與視窗開關。

網站：https://mac-tvos-evan-v47.yyum7tt03.chatgpt.site/#operation-films

此 ZIP 包含 HTML、CSS、JS、公開圖片與影片。安裝包二進位分段不放入網站原始碼快照；本機瀏覽會停用安裝包下載，正式站提供既有下載入口。

預覽：在 website 目錄執行 python3 -m http.server 8000，再開 http://localhost:8000 。影片為不同開發階段實機錄影，保留原速。
